# Distance Measurement System using Arduino UNO

Professional template repository.

## Features
- HC-SR04 ultrasonic sensor
- Distance in cm
- Serial monitor output
- Easy to extend with LCD/OLED, buzzer, LEDs

Replace the placeholder images with your own screenshots.
